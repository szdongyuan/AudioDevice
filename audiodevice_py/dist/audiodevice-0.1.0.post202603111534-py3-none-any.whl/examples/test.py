import numpy as np
import audiodevice as ad

ad.init()
ad.default.hostapi = "WASAPI"  # 带 Windows 前缀
# ad.default.device = [1, 3]
ad.default.device = [10,12]
ad.default.channels = [6,2]

# 参数单独设置
duration = 2.0      # 播放时长，单位秒
fs = 48000           # 采样率（Hz）
frequency = 1000.0  # 音调频率

# 生成正弦波音频数据
t = np.linspace(0, duration, int(fs * duration), endpoint=False)
audio_data = 0.5 * np.sin(2 * np.pi * frequency * t)  # 振幅在 [-0.5, 0.5]

# ad.play(audio_data, blocking=True, samplerate=fs)
y = ad.rec(5*fs, blocking=True, samplerate=fs,wav_path="test.wav",save_wav=True)