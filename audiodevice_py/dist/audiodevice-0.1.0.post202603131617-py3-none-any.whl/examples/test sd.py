"""
最简 sounddevice 输出流示例：播放 1000Hz 正弦波几秒。
与 demo_stream_output.py 对应，便于对比 mono/stereo 行为。
"""
import numpy as np
import sounddevice as sd

# 可选：指定设备 (input_index, output_index)，不设则用系统默认
# sd.default.device = (None, 17)
# sd.default.samplerate = 48000

sr = int(sd.default.samplerate or 48000)
duration_s = 3
freq = 1000.0
phase = [0.0]

def callback(outdata, frames, time_info, status):
    t = (phase[0] + np.arange(frames, dtype=np.float32)) / sr
    phase[0] += frames
    outdata[:, 0] = 0.5 * np.sin(2 * np.pi * freq * t)
    if outdata.shape[1] > 1:
        outdata[:, 1] = outdata[:, 0]  # 双通道时复制到右声道（与 mono 听感一致）

# 单通道：channels=1，驱动会 upmix 到双耳
# 双通道：channels=2，callback 里已复制到右声道，听感同 mono
channels = 1

with sd.OutputStream(channels=channels, samplerate=sr, callback=callback, blocksize=2048):
    sd.sleep(int(duration_s * 1000))
print("完成")
