from pathlib import Path
import os
import wave

import numpy as np
import audiodevice as ad


def _write_wav_int16(path: str, samplerate: int, data: np.ndarray) -> None:
    x = np.asarray(data, dtype=np.float32)
    if x.ndim == 1:
        x = x[:, None]
    x = np.clip(x, -1.0, 1.0)
    pcm = (x * 32767.0).astype("<i2", copy=False)
    with wave.open(path, "wb") as wf:
        wf.setnchannels(int(pcm.shape[1]))
        wf.setsampwidth(2)
        wf.setframerate(int(samplerate))
        wf.writeframes(pcm.tobytes(order="C"))


def _pick_matching_output_device_for_input(input_idx: int) -> int | None:
    try:
        in_dev = ad.query_devices(int(input_idx))
        in_host = int(in_dev.get("hostapi", -1))
        if in_host < 0:
            return None
        for d in ad.query_devices():
            if int(d.get("hostapi", -1)) != in_host:
                continue
            if int(d.get("max_output_channels", 0) or 0) > 0:
                return int(d.get("index", -1))
    except Exception:
        return None
    return None


def main() -> None:
    # 尽量使用同目录下的 audiodevice.exe（如果存在）
    root = Path(__file__).resolve().parent.parent
    engine = root / "audiodevice.exe"
    if engine.is_file():
        ad.init(engine_exe=str(engine), engine_cwd=str(root), timeout=10)
    else:
        ad.init(timeout=10)

    # 按你的要求固定设备：(输入, 输出)
    want_in, want_out = 22, 31
    try:
        ad.default.device = (want_in, want_out)
    except ValueError as e:
        # playrec 必须同 hostapi；如果 (22,31) 不满足，就在同 hostapi 内自动找一个可输出设备配对
        picked_out = _pick_matching_output_device_for_input(want_in)
        if picked_out is None:
            raise
        print("提示：你指定的 ad.default.device=(22,31) 不可用于全双工 playrec：", e)
        print(f"自动改用 device=({want_in},{picked_out})（保证同 hostapi）")
        ad.default.device = (want_in, int(picked_out))
    ad.default.samplerate = 48_000

    fs = int(ad.default.samplerate or 48_000)
    duration_s = 2.0
    frames = int(fs * duration_s)
    t = np.arange(frames, dtype=np.float32) / fs

    # 播放：单声道 1kHz
    y = (0.1 * np.sin(2 * np.pi * 1000.0 * t)).astype(np.float32)

    # 录音：默认录 1 声道（你也可以改成 channels=2/6 等）
    x = ad.playrec(y, blocking=True, channels=1, save_wav=False)

    wav_path = os.path.join(os.path.dirname(__file__), "test_playrec.wav")
    _write_wav_int16(wav_path, fs, x)

    print("device =", tuple(ad.default.device))
    print("captured =", np.asarray(x).shape, np.asarray(x).dtype)
    print("wav_path =", os.path.abspath(wav_path))


if __name__ == "__main__":
    main()