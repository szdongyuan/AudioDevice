import numpy as np
import audiodevice as ad
import os

ad.init()

ad.default.device = [10,12]
print(ad.default.device)
print(ad.query_devices())   
