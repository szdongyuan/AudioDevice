import numpy as np
import sounddevice as sd

sd.default.device = (111,211)
print(sd.default.device)
print(sd.query_devices())