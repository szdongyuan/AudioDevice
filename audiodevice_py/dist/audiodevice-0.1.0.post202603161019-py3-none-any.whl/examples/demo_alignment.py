"""
demo_alignment.py - 验证 playrec / stream_playrecord 的 alignment(GCC-PHAT) 是否真的对齐

使用前提（重要）：
- 需要有“回放 -> 录音”的物理或虚拟回路，否则录到的内容与播放无关，无法验证对齐效果。
  - 物理：扬声器靠近麦克风 / 线缆回环
  - 虚拟：Virtual Audio Cable / 立体声混音（Stereo Mix）等

输出：
- examples/demo_alignment.png：对齐前后互相关与波形对比图
- examples/demo_alignment_*.npy：保存的 stimulus/record 数据，便于离线分析
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import argparse
import time

import numpy as np

import audiodevice as ad
from audiodevice.alignment_processing import AlignmentProcessing


@dataclass
class RunResult:
    name: str
    stimulus: np.ndarray  # (frames, out_ch)
    rec: np.ndarray  # (frames, in_ch)
    delay_samples: int
    corr: np.ndarray
    max_shift: int


def _to_mono(x: np.ndarray) -> np.ndarray:
    x = np.asarray(x, dtype=np.float32)
    if x.ndim == 1:
        return x
    if x.ndim == 2:
        if x.shape[1] == 1:
            return x[:, 0]
        return np.mean(x, axis=1)
    raise ValueError("audio array must be 1D or 2D")


def _chirp(fs: int, duration_s: float, f0: float, f1: float, amp: float) -> np.ndarray:
    n = int(round(float(fs) * float(duration_s)))
    t = np.arange(n, dtype=np.float32) / float(fs)
    k = (float(f1) - float(f0)) / max(1e-9, float(duration_s))
    phase = 2.0 * np.pi * (float(f0) * t + 0.5 * k * t * t)
    y = np.sin(phase).astype(np.float32)
    # window to reduce clicks
    w = np.hanning(max(8, n)).astype(np.float32)
    y = (y * w) * float(amp)
    return y.astype(np.float32)


def _make_stimulus(*, fs: int, duration_s: float, out_ch: int, amp: float) -> np.ndarray:
    # 用 chirp（非周期、信息量大）比纯正弦更适合做对齐。
    y = _chirp(fs, duration_s, f0=300.0, f1=8000.0, amp=amp)
    # 加一个短脉冲增强起点辨识度（仍保持低幅度）
    if y.size >= int(0.01 * fs):
        y[: int(0.002 * fs)] += (0.5 * amp) * np.hanning(int(0.002 * fs)).astype(np.float32)

    if int(out_ch) > 1:
        y = np.stack([y] * int(out_ch), axis=1)
    else:
        y = y[:, None]
    return y.astype(np.float32)


def _estimate_delay(stimulus: np.ndarray, rec: np.ndarray) -> tuple[int, np.ndarray, int]:
    stim_m = _to_mono(stimulus)
    rec_m = _to_mono(rec)
    delay, corr, max_shift = AlignmentProcessing.gcc_phat(stim_m, rec_m)
    return int(delay), np.asarray(corr, dtype=np.float32), int(max_shift)


def _run_playrec(
    *,
    y: np.ndarray,
    fs: int,
    in_ch: int,
    delay_ms: float,
    alignment: bool,
    save_wav: bool,
    wav_path: str,
) -> RunResult:
    x = ad.playrec(
        y,
        blocking=True,
        samplerate=int(fs),
        in_channels=int(in_ch),
        delay_time=float(delay_ms),
        alignment=bool(alignment),
        save_wav=bool(save_wav),
        wav_path=str(wav_path) if wav_path else "",
    )
    d, corr, max_shift = _estimate_delay(y, x)
    return RunResult(
        name=f"playrec alignment={alignment}",
        stimulus=y,
        rec=np.asarray(x, dtype=np.float32),
        delay_samples=d,
        corr=corr,
        max_shift=max_shift,
    )


def _run_stream_playrecord(
    *,
    y: np.ndarray,
    fs: int,
    in_ch: int,
    blocksize: int,
    delay_ms: float,
    alignment: bool,
    save_wav: bool,
    wav_path: str,
) -> RunResult:
    x = ad.stream_playrecord(
        y,
        samplerate=int(fs),
        channels=int(in_ch),
        blocksize=int(blocksize),
        delay_time=float(delay_ms),
        alignment=bool(alignment),
        save_wav=bool(save_wav),
        wav_path=str(wav_path) if wav_path else "",
    )
    d, corr, max_shift = _estimate_delay(y, x)
    return RunResult(
        name=f"stream_playrecord alignment={alignment}",
        stimulus=y,
        rec=np.asarray(x, dtype=np.float32),
        delay_samples=d,
        corr=corr,
        max_shift=max_shift,
    )


def _plot(results: list[RunResult], *, fs: int, out_png: Path) -> None:
    try:
        import matplotlib.pyplot as plt
    except Exception as e:
        raise RuntimeError(
            "需要 matplotlib 才能画图。请先安装：pip install matplotlib"
        ) from e

    # 布局：每个 method 一列（playrec / stream），三行：波形叠加、corr(raw)、corr(aligned)
    cols = 2
    rows = 3
    fig, axes = plt.subplots(rows, cols, figsize=(14, 9), constrained_layout=True)

    def _pick(prefix: str, aligned: bool) -> RunResult:
        key = f"{prefix} alignment={aligned}"
        for r in results:
            if r.name == key:
                return r
        raise KeyError(key)

    pairs = [
        ("playrec", 0),
        ("stream_playrecord", 1),
    ]

    for prefix, col in pairs:
        r_raw = _pick(prefix, False)
        r_aln = _pick(prefix, True)

        stim_m = _to_mono(r_raw.stimulus)
        raw_m = _to_mono(r_raw.rec)
        aln_m = _to_mono(r_aln.rec)

        # 1) 波形叠加：只画前 200ms，避免太密
        n_show = min(int(0.2 * fs), stim_m.size, raw_m.size, aln_m.size)
        t_ms = (np.arange(n_show, dtype=np.float32) / float(fs)) * 1000.0
        ax0 = axes[0, col]
        ax0.plot(t_ms, stim_m[:n_show], lw=1.0, label="stimulus(mono)")
        ax0.plot(t_ms, raw_m[:n_show], lw=1.0, label="rec raw(mono)")
        ax0.plot(t_ms, aln_m[:n_show], lw=1.0, label="rec aligned(mono)")
        ax0.set_title(f"{prefix}: waveform overlay (first 200ms)")
        ax0.set_xlabel("time (ms)")
        ax0.set_ylabel("amp")
        ax0.grid(True, alpha=0.25)
        ax0.legend(loc="upper right", fontsize=9)

        # 2) corr(raw)
        ax1 = axes[1, col]
        lag_raw = (np.arange(r_raw.corr.size, dtype=np.int32) - int(r_raw.max_shift)).astype(np.int32)
        ax1.plot(lag_raw, r_raw.corr, lw=1.0)
        ax1.axvline(int(r_raw.delay_samples), color="r", ls="--", lw=1.0, label=f"delay={r_raw.delay_samples} samples")
        ax1.set_title(f"{prefix}: GCC-PHAT corr (raw), delay={r_raw.delay_samples} samples")
        ax1.set_xlabel("lag (samples)")
        ax1.set_ylabel("corr")
        ax1.grid(True, alpha=0.25)
        ax1.legend(loc="upper right", fontsize=9)

        # 3) corr(aligned)
        ax2 = axes[2, col]
        lag_aln = (np.arange(r_aln.corr.size, dtype=np.int32) - int(r_aln.max_shift)).astype(np.int32)
        ax2.plot(lag_aln, r_aln.corr, lw=1.0)
        ax2.axvline(int(r_aln.delay_samples), color="r", ls="--", lw=1.0, label=f"delay={r_aln.delay_samples} samples")
        ax2.set_title(f"{prefix}: GCC-PHAT corr (aligned), delay={r_aln.delay_samples} samples")
        ax2.set_xlabel("lag (samples)")
        ax2.set_ylabel("corr")
        ax2.grid(True, alpha=0.25)
        ax2.legend(loc="upper right", fontsize=9)

    fig.suptitle("Alignment test: playrec vs stream_playrecord (GCC-PHAT)", fontsize=14)
    fig.savefig(str(out_png), dpi=150)


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--fs", type=int, default=48_000)
    p.add_argument("--duration", type=float, default=2.0)
    p.add_argument("--out-ch", type=int, default=2)
    p.add_argument("--in-ch", type=int, default=1)
    p.add_argument("--amp", type=float, default=0.1)
    p.add_argument("--delay-ms", type=float, default=200.0, help="人为加一个录音窗口延时，便于看到 raw 的错位")
    p.add_argument("--blocksize", type=int, default=1024, help="stream_playrecord blocksize")
    p.add_argument("--skip-stream", action="store_true")
    p.add_argument("--skip-playrec", action="store_true")
    p.add_argument("--save-wav", action="store_true")
    args = p.parse_args()

    # init engine（与其他 demo 一致）
    _root = Path(__file__).resolve().parent.parent
    _engine = _root / "audiodevice.exe"
    if _engine.is_file():
        ad.init(engine_exe=str(_engine), engine_cwd=str(_root), timeout=10)
    else:
        ad.init(timeout=10)

    # 指定默认输入/输出设备：(input_device_index, output_device_index)
    ad.default.device = (14, 18)
    ad.print_default_devices()

    # 打印所选设备能力，且根据设备能力做最小限度的容错（避免 sr/ch 不支持直接崩）
    dev_in_idx, dev_out_idx = ad.default.device
    dev_in_info = None
    dev_out_info = None
    try:
        dev_in_info = ad.query_devices(int(dev_in_idx))
        dev_out_info = ad.query_devices(int(dev_out_idx))
        print("Selected default.device:", (int(dev_in_idx), int(dev_out_idx)))
        print(
            "Input:",
            dev_in_info.get("name", ""),
            "max_in_ch=",
            dev_in_info.get("max_input_channels", ""),
            "default_sr=",
            dev_in_info.get("default_samplerate", ""),
        )
        print(
            "Output:",
            dev_out_info.get("name", ""),
            "max_out_ch=",
            dev_out_info.get("max_output_channels", ""),
            "default_sr=",
            dev_out_info.get("default_samplerate", ""),
        )
        print()
    except Exception:
        pass

    def _get_int(d, k: str, default_v: int = 0) -> int:
        try:
            if isinstance(d, dict):
                return int(d.get(k, default_v) or default_v)
        except Exception:
            pass
        return int(default_v)

    # 常见误配置：把 output-only 设备填到 input 位置（max_input_channels=0）。
    # 如果检测到明显填反，则自动交换，避免出现 “no supported input config for sr/ch”。
    max_in_ch = _get_int(dev_in_info, "max_input_channels", 0)
    max_in_ch_alt = _get_int(dev_out_info, "max_input_channels", 0)
    max_out_ch = _get_int(dev_out_info, "max_output_channels", 0)
    max_out_ch_alt = _get_int(dev_in_info, "max_output_channels", 0)
    if (max_in_ch <= 0 and max_in_ch_alt > 0) or (max_out_ch <= 0 and max_out_ch_alt > 0):
        print("提示：检测到 default.device 可能填反（输入/输出能力不匹配），已自动交换为 (18, 14)")
        ad.default.device = (int(dev_out_idx), int(dev_in_idx))
        dev_in_idx, dev_out_idx = ad.default.device
        try:
            dev_in_info = ad.query_devices(int(dev_in_idx))
            dev_out_info = ad.query_devices(int(dev_out_idx))
        except Exception:
            pass
        max_in_ch = _get_int(dev_in_info, "max_input_channels", 0)
        max_out_ch = _get_int(dev_out_info, "max_output_channels", 0)
        print()

    in_ch_req = int(args.in_ch)
    try:
        max_in = int(dev_in_info.get("max_input_channels", 0)) if isinstance(dev_in_info, dict) else 0
        if max_in > 0 and in_ch_req > max_in:
            print(f"提示：in_ch={in_ch_req} 超过设备 max_input_channels={max_in}，已裁剪为 {max_in}")
            in_ch_req = int(max_in)
    except Exception:
        pass
    if in_ch_req <= 0:
        in_ch_req = 1

    out_ch_req = int(args.out_ch)
    try:
        max_out = int(dev_out_info.get("max_output_channels", 0)) if isinstance(dev_out_info, dict) else 0
        if max_out > 0 and out_ch_req > max_out:
            print(f"提示：out_ch={out_ch_req} 超过设备 max_output_channels={max_out}，已裁剪为 {max_out}")
            out_ch_req = int(max_out)
    except Exception:
        pass
    if out_ch_req <= 0:
        out_ch_req = 1

    def _uniq(seq):
        out = []
        for v in seq:
            if v is None:
                continue
            try:
                iv = int(v)
            except Exception:
                continue
            if iv not in out:
                out.append(iv)
        return out

    def _candidate_in_ch(req: int) -> list[int]:
        max_in = _get_int(dev_in_info, "max_input_channels", 0)
        c = _uniq([req, max_in, 2, 1])
        if max_in > 0:
            c = [v for v in c if 1 <= int(v) <= int(max_in)]
        else:
            c = [v for v in c if int(v) >= 1]
        return c or [max(1, int(req))]

    def _candidate_out_ch(req: int) -> list[int]:
        max_out = _get_int(dev_out_info, "max_output_channels", 0)
        c = _uniq([req, max_out, 2, 1])
        if max_out > 0:
            c = [v for v in c if 1 <= int(v) <= int(max_out)]
        else:
            c = [v for v in c if int(v) >= 1]
        return c or [max(1, int(req))]

    fs = int(args.fs)
    y = _make_stimulus(fs=fs, duration_s=float(args.duration), out_ch=int(out_ch_req), amp=float(args.amp))

    out_dir = Path(__file__).resolve().parent
    np.save(str(out_dir / "demo_alignment_stimulus.npy"), y)

    results: list[RunResult] = []

    print("=== Alignment demo ===")
    print("提示：请确保有回放->录音回路，否则无法验证对齐。")
    print(f"fs={fs}, duration={args.duration}s, out_ch={out_ch_req}, in_ch={in_ch_req}, delay_ms={args.delay_ms}")
    print()

    def _wav(name: str) -> str:
        return str(out_dir / name) if bool(args.save_wav) else ""

    def _is_sr_ch_unsupported(err: BaseException) -> bool:
        s = str(err).lower()
        return ("no supported input config" in s) or ("no supported output config" in s) or ("sr/ch" in s)

    def _candidate_fs(cur: int) -> list[int]:
        cands = []
        for v in [
            (dev_out_info.get("default_samplerate", None) if isinstance(dev_out_info, dict) else None),
            (dev_in_info.get("default_samplerate", None) if isinstance(dev_in_info, dict) else None),
            48_000,
            44_100,
        ]:
            try:
                if v is None:
                    continue
                vv = int(float(v))
                if vv > 0 and vv not in cands:
                    cands.append(vv)
            except Exception:
                pass
        # 确保当前 fs 在首位（先用用户指定的）
        if int(cur) in cands:
            cands.remove(int(cur))
        return [int(cur)] + cands

    def _regen_stimulus(fs_eff: int, out_ch_eff: int) -> np.ndarray:
        yy = _make_stimulus(
            fs=int(fs_eff),
            duration_s=float(args.duration),
            out_ch=int(out_ch_eff),
            amp=float(args.amp),
        )
        np.save(str(out_dir / "demo_alignment_stimulus.npy"), yy)
        return yy

    if not bool(args.skip_playrec):
        t0 = time.perf_counter()
        last_err = None
        r0 = r1 = None  # type: ignore[assignment]
        ok = False
        for fs_try in _candidate_fs(fs):
            for out_ch_try in _candidate_out_ch(out_ch_req):
                for in_ch_try in _candidate_in_ch(in_ch_req):
                    try:
                        fs = int(fs_try)
                        if y.shape[0] <= 0 or int(out_ch_try) != int(y.shape[1]) or int(fs_try) != int(args.fs):
                            y = _regen_stimulus(int(fs_try), int(out_ch_try))
                        r0 = _run_playrec(
                            y=y,
                            fs=int(fs_try),
                            in_ch=int(in_ch_try),
                            delay_ms=float(args.delay_ms),
                            alignment=False,
                            save_wav=bool(args.save_wav),
                            wav_path=_wav("demo_alignment_playrec_raw.wav"),
                        )
                        r1 = _run_playrec(
                            y=y,
                            fs=int(fs_try),
                            in_ch=int(in_ch_try),
                            delay_ms=float(args.delay_ms),
                            alignment=True,
                            save_wav=bool(args.save_wav),
                            wav_path=_wav("demo_alignment_playrec_aligned.wav"),
                        )
                        ok = True
                        break
                    except RuntimeError as e:
                        last_err = e
                        if _is_sr_ch_unsupported(e):
                            continue
                        raise
                if ok:
                    break
            if ok:
                break
        if r0 is None or r1 is None:
            raise last_err  # type: ignore[misc]
        results += [r0, r1]
        np.save(str(out_dir / "demo_alignment_playrec_raw.npy"), r0.rec)
        np.save(str(out_dir / "demo_alignment_playrec_aligned.npy"), r1.rec)
        print(f"[playrec] raw delay={r0.delay_samples} samples; aligned delay={r1.delay_samples} samples; elapsed={(time.perf_counter()-t0):.2f}s")

    if not bool(args.skip_stream):
        t0 = time.perf_counter()
        last_err = None
        r0 = r1 = None  # type: ignore[assignment]
        ok = False
        for fs_try in _candidate_fs(fs):
            for out_ch_try in _candidate_out_ch(out_ch_req):
                for in_ch_try in _candidate_in_ch(in_ch_req):
                    try:
                        fs = int(fs_try)
                        if y.shape[0] <= 0 or int(out_ch_try) != int(y.shape[1]) or int(fs_try) != int(args.fs):
                            y = _regen_stimulus(int(fs_try), int(out_ch_try))
                        r0 = _run_stream_playrecord(
                            y=y,
                            fs=int(fs_try),
                            in_ch=int(in_ch_try),
                            blocksize=int(args.blocksize),
                            delay_ms=float(args.delay_ms),
                            alignment=False,
                            save_wav=bool(args.save_wav),
                            wav_path=_wav("demo_alignment_stream_raw.wav"),
                        )
                        r1 = _run_stream_playrecord(
                            y=y,
                            fs=int(fs_try),
                            in_ch=int(in_ch_try),
                            blocksize=int(args.blocksize),
                            delay_ms=float(args.delay_ms),
                            alignment=True,
                            save_wav=bool(args.save_wav),
                            wav_path=_wav("demo_alignment_stream_aligned.wav"),
                        )
                        ok = True
                        break
                    except RuntimeError as e:
                        last_err = e
                        if _is_sr_ch_unsupported(e):
                            continue
                        raise
                if ok:
                    break
            if ok:
                break
        if r0 is None or r1 is None:
            raise last_err  # type: ignore[misc]
        results += [r0, r1]
        np.save(str(out_dir / "demo_alignment_stream_raw.npy"), r0.rec)
        np.save(str(out_dir / "demo_alignment_stream_aligned.npy"), r1.rec)
        print(f"[stream] raw delay={r0.delay_samples} samples; aligned delay={r1.delay_samples} samples; elapsed={(time.perf_counter()-t0):.2f}s")

    if len(results) >= 2:
        out_png = out_dir / "demo_alignment.png"
        _plot(results, fs=fs, out_png=out_png)
        print()
        print("saved:", str(out_png))


if __name__ == "__main__":
    main()

