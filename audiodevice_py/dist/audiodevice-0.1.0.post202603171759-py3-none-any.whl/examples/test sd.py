import sounddevice as sd
import time

samplerate = 48000
blocksize = 1024

def callback(indata, frames, time_info, status):
    if status:
        print("Status:", status)

    # ❌ 故意让 callback 变慢（模拟你现在的场景）
    time.sleep(0.05)   # 50ms > 21ms（block 时长）

with sd.InputStream(
    samplerate=samplerate,
    blocksize=blocksize,
    channels=1,
    callback=callback,
):
    print("Running overflow test...")
    sd.sleep(10000)